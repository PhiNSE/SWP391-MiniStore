package com.sitesquad.ministore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MinistoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
